TOM GOODWIN PRESS KIT
Contains: bios.txt, fact-sheet.txt
To add before launch: headshots (x3), GAMEPLAN. + wordmark logos (SVG/PNG), PDF fact sheet.
Contact: press@tomgoodwin.london
